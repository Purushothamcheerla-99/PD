README

This workshop contains collaterals for RTL Design and Synthesis Workshop using Sky130 PDK's
In case of you any queries, please feel free to drop an email to kunalpghosh@gmail.com and vsd@vlsisystemdesign.com

